﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using TwitterClone.Business;
using TwitterClone.Model;

namespace TwitterClone.Web.Controllers
{
    [AllowAnonymous]
    public class AccountController : Controller
    {
        [AllowAnonymous]
        // GET: Account
        public ActionResult Login()
        {
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public ActionResult Login(LoginViewModel model)
        {
            UserManagement userMgmt = new UserManagement();
            UserViewModel user = userMgmt.ValidateUser(model);

            if (user != null)
            {
                FormsAuthentication.SetAuthCookie(user.UserId, false);
                return RedirectToAction("Index", "Home");
            }

            return View();
        }

        [AllowAnonymous]
        // GET: Account
        public ActionResult Register()
        {
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public ActionResult Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                UserManagement userMgmt = new UserManagement();

                // check whether user id already exists
                bool userExists = userMgmt.IsUserExists(model.UserId);

                if (!userExists)
                {
                    userMgmt.RegisterUser(model);
                    return RedirectToAction("Login");
                }
                else
                {
                    model.Message = "User id already registered. Please try different user id";
                }
            }

            return View(model);
        }


        [Authorize]
        // GET: Account
        public ActionResult Manage()
        {
            string userId = HttpContext.User.Identity.Name;

            UserManagement userMgmt = new UserManagement();
            UserViewModel user = userMgmt.GetUserById(userId);

            RegisterViewModel manageUser = new RegisterViewModel();
            manageUser.UserId = user.UserId;
            manageUser.UserName = user.UserName;
            manageUser.Email = user.Email;

            return View(manageUser);
        }

        [Authorize]
        [HttpPost]
        public ActionResult Manage(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                UserManagement userMgmt = new UserManagement();
                userMgmt.EditUserProfile(model);
                return RedirectToAction("Index", "Home");
            }

            return View(model);
        }

        [Authorize]
        [HttpPost]
        public ActionResult Delete(RegisterViewModel model)
        {
            if (!string.IsNullOrEmpty(model.UserId))
            {
                UserManagement userMgmt = new UserManagement();
                userMgmt.DeleteProfile(model.UserId);
                return RedirectToAction("LogOff");
            }

            return View(model);
        }

        [Authorize]
        public ActionResult LogOff()
        {
            // close the session
            FormsAuthentication.SignOut();
            Session.Abandon();

            // clear the cookie
            HttpCookie cookie = new HttpCookie(FormsAuthentication.FormsCookieName, "");
            cookie.Expires = DateTime.Now.AddDays(-1);
            Response.Cookies.Add(cookie);

            // redirect to login page
            FormsAuthentication.RedirectToLoginPage();

            return RedirectToAction("Login");
        }
    }
}