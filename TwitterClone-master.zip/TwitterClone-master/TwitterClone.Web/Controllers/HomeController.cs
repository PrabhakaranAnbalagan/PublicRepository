﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TwitterClone.Business;
using TwitterClone.Model;

namespace TwitterClone.Web.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            PostTweetModel postTweetModel = new PostTweetModel();
            postTweetModel.UserId = HttpContext.User.Identity.Name;
            return View(postTweetModel);
        }

        [HttpPost]
        public ActionResult Index(PostTweetModel postTweetModel)
        {
            if (ModelState.IsValid)
            {
                TweetManagement tweetMgmt = new TweetManagement();
                postTweetModel.UserId = HttpContext.User.Identity.Name;
                tweetMgmt.PostTweet(postTweetModel);

                return RedirectToAction("Index");
            }

            return View(postTweetModel);
        }


        [HttpGet]
        public ActionResult GetTweets()
        {
            string userId = HttpContext.User.Identity.Name;

            TweetManagement tweetMgmt = new TweetManagement();

            // get the tweets for displaying in home screen
            List<TweetModel> tweetModel = tweetMgmt.GetTweets(userId);

            // return as partial view
            return PartialView("_Tweets", tweetModel);
        }


        [HttpGet]
        public ActionResult GetTweetsCount()
        {
            string userId = HttpContext.User.Identity.Name;

            TweetManagement tweetMgmt = new TweetManagement();

            // get the tweets count
            TweetCountModel tweetCountModel = tweetMgmt.GetTweetsCount(userId);

            // return as partial view
            return PartialView("_tweetsCount", tweetCountModel);
        }
    }
}