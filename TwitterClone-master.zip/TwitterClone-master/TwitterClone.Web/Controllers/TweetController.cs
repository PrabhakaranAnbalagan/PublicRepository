﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TwitterClone.Model;
using TwitterClone.Business;

namespace TwitterClone.Web.Controllers
{
    public class TweetController : ApiController
    {
        [HttpPost]
        [ActionName("PostTweet")]
        // Post
        public bool PostTweet(PostTweetModel model)
        {
            TweetManagement tweetMgmt = new TweetManagement();
            return tweetMgmt.PostTweet(model);
        }

        [HttpGet]
        [ActionName("GetTweetById")]
        public TweetModel GetTweetById(int tweetId)
        {
            TweetManagement tweetMgmt = new TweetManagement();
            return tweetMgmt.GetTweetById(tweetId);
        }

        [HttpPost]
        [ActionName("EditTweet")]
        public bool EditTweet(PostTweetModel model)
        {
            TweetManagement tweetMgmt = new TweetManagement();
            return tweetMgmt.EditTweet(model);
        }

        [HttpPost]
        [ActionName("DeleteTweet")]
        public bool DeleteTweet(PostTweetModel model)
        {
            TweetManagement tweetMgmt = new TweetManagement();
            return tweetMgmt.DeleteTweet(model);
        }

        [HttpGet]
        [ActionName("SearchUsers")]
        public UserViewModel SearchUsers(string user)
        {
            UserManagement userMgmt = new UserManagement();
            return userMgmt.SearchUsers(user);
        }

        [HttpPost]
        [ActionName("FollowUser")]
        public bool FollowUser(FollowUserModel model)
        {
            TweetManagement tweetMgmt = new TweetManagement();
            return tweetMgmt.FollowUser(model);
        }
    }
}
