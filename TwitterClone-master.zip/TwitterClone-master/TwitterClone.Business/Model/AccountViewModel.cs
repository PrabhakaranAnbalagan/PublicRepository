﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace TwitterClone.Model
{
    public class LoginViewModel
    {
        [Display(Name ="User Id")]
        [StringLength(24)]
        public string UserId { get; set; }

        [Display(Name = "Password")]
        [StringLength(40)]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }

    public class RegisterViewModel
    {
        [Required(ErrorMessage = "User id is required")]
        [Display(Name = "User Id")]
        [StringLength(24)]
        public string UserId { get; set; }

        [Required(ErrorMessage = "User name is required")]
        [Display(Name = "User Name")]
        [StringLength(40)]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Email address is required")]
        [Display(Name = "Email")]
        [DataType(DataType.EmailAddress)]
        [StringLength(80, ErrorMessage = "The {0} must be at least {2} characters long.")]
        public string Email { get; set; }

        [Required]
        [StringLength(80, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }


        public string Message { get; set; }
    }
}
