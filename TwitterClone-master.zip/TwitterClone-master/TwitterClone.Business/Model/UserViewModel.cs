﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwitterClone.Model
{
    public class UserViewModel
    {
        [Required]
        [StringLength(24)]
        public string UserId { get; set; }

        [Required]
        [StringLength(40)]
        public string UserName { get; set; }

        [Required]
        [StringLength(80)]
        public string Email { get; set; }

        public DateTime JoinedDate { get; set; }

        public bool IsActive { get; set; }

        public bool IsFollowing { get; set; }
    }
}
