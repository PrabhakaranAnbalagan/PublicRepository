﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace TwitterClone.Model
{
    public class PostTweetModel
    {
        [Required]
        [StringLength(140)]
        public string Message { get; set; }

        public string UserId { get; set; }

        public int TweetId { get; set; }
    }

    public class TweetCountModel
    {
        public int TweetsCount { get; set; }

        public int FollowersCount { get; set; }

        public int FollowingCount { get; set; }
    }

    public class TweetModel
    {
        public int TweetId { get; set; }

        public string UserId { get; set; }

        public string UserName { get; set; }

        public DateTime CreatedDate { get; set; }

        public string Message { get; set; }

        public bool OwnTweet { get; set; }
    }

    public class FollowUserModel
    {
        public string FollowUserId { get; set; }

        public string UserId { get; set; }

        public string FollowType { get; set; }
    }
}
