﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using TwitterClone.Domain;
using TwitterClone.Model;

namespace TwitterClone.Business
{
    public class UserManagement
    {
        private TwitterCloneDbContext dbCntx;

        public UserManagement()
        {
            dbCntx = new TwitterCloneDbContext();
        }

        public bool RegisterUser(RegisterViewModel model)
        {
            bool status = false;
            string encryptedPassword = EncryptStringUsingMD5(model.Password);

            User user = new User();
            user.UserId = model.UserId;
            user.UserName = model.UserName;
            user.Password = encryptedPassword;
            user.Email = model.Email;
            user.JoinedDate = DateTime.Now;
            user.IsActive = true;

            dbCntx.User.Add(user);
            dbCntx.SaveChanges();

            return status;
        }

        public UserViewModel ValidateUser(LoginViewModel model)
        {
            User user = dbCntx.User.FirstOrDefault(u => u.UserId == model.UserId);

            if (user != null)
            {
                string encryptedPassword = EncryptStringUsingMD5(model.Password);

                if (user.Password == encryptedPassword)
                {
                    UserViewModel userModel = new UserViewModel();
                    userModel.UserId = user.UserId;
                    userModel.UserName = user.UserName;
                    userModel.Email = user.Email;
                    userModel.JoinedDate = user.JoinedDate;
                    userModel.IsActive = user.IsActive;
                    return userModel;
                }
            }

            return null;
        }

        public UserViewModel GetUserById(string userId)
        {
            User user = dbCntx.User.FirstOrDefault(u => u.UserId == userId);

            if (user != null)
            {
                UserViewModel userModel = new UserViewModel();
                userModel.UserId = user.UserId;
                userModel.UserName = user.UserName;
                userModel.Email = user.Email;
                return userModel;
            }

            return null;
        }

        public bool EditUserProfile(RegisterViewModel model)
        {
            User user = dbCntx.User.FirstOrDefault(u => u.UserId == model.UserId);

            if (user != null)
            {
                string encryptedPassword = EncryptStringUsingMD5(model.Password);

                UserViewModel userModel = new UserViewModel();
                user.UserName = model.UserName;
                user.Email = model.Email;
                user.Password = encryptedPassword;

                dbCntx.User.Attach(user);
                dbCntx.Entry<User>(user).State = System.Data.Entity.EntityState.Modified;
                dbCntx.SaveChanges();

                return true;
            }

            return false;
        }

        public bool DeleteProfile(string userId)
        {
            User user = dbCntx.User.FirstOrDefault(u => u.UserId == userId);

            if (user != null)
            {
                dbCntx.User.Remove(user);
                dbCntx.SaveChanges();
                return true;
            }

            return false;
        }

        public bool IsUserExists(string UserId)
        {
            bool exists = false;

            exists = dbCntx.User.Any(u => u.UserId == UserId);
            
            return exists;
        }

        public UserViewModel SearchUsers(string user)
        {
            UserViewModel userRes;

            userRes = dbCntx.User.Where(u => (u.UserId == user)).Select(u => new UserViewModel
            {
                UserId = u.UserId,
                UserName = u.UserName
            }).FirstOrDefault();

            var following = dbCntx.Following.Where(u => u.UserId == HttpContext.Current.User.Identity.Name).Select(u => u.FollowingUserId).ToList();

            if (following.Contains(userRes.UserId))
                userRes.IsFollowing = true;

            return userRes;
        }
        

        private string EncryptStringUsingMD5(string input)
        {
            using (MD5 md5Hash = MD5.Create())
            {
                // Convert the input string to a byte array and compute the hash. 
                byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input));

                // Create a new Stringbuilder to collect the bytes and create a string. 
                StringBuilder sBuilder = new StringBuilder();

                // Loop through each byte of the hashed data
                // and format each one as a hexadecimal string. 
                for (int i = 0; i < (data.Length); i++)
                {
                    sBuilder.Append(data[i].ToString("X2"));
                }

                // Return the hexadecimal string.
                return sBuilder.ToString();
            }
        }
    }
}
