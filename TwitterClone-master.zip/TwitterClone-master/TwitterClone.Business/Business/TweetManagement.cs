﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TwitterClone.Domain;
using TwitterClone.Model;

namespace TwitterClone.Business
{
    public class TweetManagement
    {
        private TwitterCloneDbContext dbCntx;

        public TweetManagement()
        {
            dbCntx = new TwitterCloneDbContext();
        }

        public bool PostTweet(PostTweetModel model)
        {
            bool status = false;

            Tweet tweet = new Tweet();
            tweet.UserId = model.UserId;
            tweet.Message = model.Message;
            tweet.Created = DateTime.Now;

            dbCntx.Tweet.Add(tweet);
            dbCntx.SaveChanges();

            return status;
        }

        public bool EditTweet(PostTweetModel model)
        {
            bool status = false;

            Tweet tweet = dbCntx.Tweet.FirstOrDefault(t => t.Id == model.TweetId);
            
            tweet.Message = model.Message;
            tweet.Created = DateTime.Now;

            dbCntx.Tweet.Attach(tweet);
            dbCntx.Entry<Tweet>(tweet).State = System.Data.Entity.EntityState.Modified;
            dbCntx.SaveChanges();

            return status;
        }

        public bool DeleteTweet(PostTweetModel model)
        {
            bool status = false;

            Tweet tweet = dbCntx.Tweet.FirstOrDefault(t => t.Id == model.TweetId);
            dbCntx.Tweet.Remove(tweet);
            dbCntx.SaveChanges();

            return status;
        }

        public List<TweetModel> GetTweets(string userId)
        {
            // get the list of users the current user is following
            var users = dbCntx.Following.Where(u => u.UserId == userId).Select(u => u.FollowingUserId).ToList();

            // get the logged-in user tweet and the tweets by users the logged-in user following
            var tweets = (from tweet in dbCntx.Tweet

                          where (users.Contains(tweet.UserId) || tweet.UserId == userId)

                          select new TweetModel
                          {
                              TweetId = tweet.Id,
                              UserId = tweet.UserId,
                              UserName = tweet.User.UserName,
                              Message = tweet.Message,
                              CreatedDate = tweet.Created,
                              OwnTweet = tweet.UserId == userId
                          }).ToList();

            return tweets;
        }

        public TweetCountModel GetTweetsCount(string userId)
        {
            TweetCountModel tweetCountModel = new TweetCountModel();

            // tweets count by the logged-in user
            tweetCountModel.TweetsCount = dbCntx.Tweet.Count(t => t.UserId == userId);

            // count of user the logged-in user is following
            tweetCountModel.FollowingCount = dbCntx.Following.Count(t => t.UserId == userId);

            // followers for the logged-in user
            tweetCountModel.FollowersCount = dbCntx.Following.Count(t => t.FollowingUserId == userId);

            return tweetCountModel;
        }

        public TweetModel GetTweetById(int tweetId)
        {
            // get the logged-in user tweet and the tweets by users the logged-in user following
            var tweet = (from twt in dbCntx.Tweet

                         where twt.Id == tweetId

                         select new TweetModel
                         {
                             TweetId = twt.Id,
                             Message = twt.Message,
                         }).FirstOrDefault();

            return tweet;
        }

        public bool FollowUser(FollowUserModel followUser)
        {
            bool status = false;

            if (followUser.FollowType == "2")
            {
                Following follow = new Following();
                follow.UserId = followUser.UserId;
                follow.FollowingUserId = followUser.FollowUserId;
                dbCntx.Following.Add(follow);
                dbCntx.SaveChanges();
            }
            else
            {
                var follow = dbCntx.Following.FirstOrDefault(f => f.UserId == followUser.UserId && f.FollowingUserId == followUser.FollowUserId);
                dbCntx.Following.Remove(follow);
                dbCntx.SaveChanges();
            }            

            return status;
        }
    }
}
