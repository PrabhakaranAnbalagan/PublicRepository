﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TwitterClone.Domain
{
    public class Tweet
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Required]
        public int Id { get; set; }

        [Required]
        [StringLength(24)]
        public string UserId { get; set; }

        [Required]
        [StringLength(140)]
        public string Message { get; set; }

        [Required]
        public DateTime Created { get; set; }

        [ForeignKey("UserId")]
        public User User { get; set; }        
    }
}
