﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TwitterClone.Domain
{
    public class Following
    {
        [Required]
        [StringLength(24)]
        [Key]
        [Column(Order =0)]
        public string UserId { get; set; }

        [Required]
        [StringLength(24)]
        [Key]
        [Column(Order = 1)]
        public string FollowingUserId { get; set; }

        [ForeignKey("UserId")]
        public User User { get; set; }

        [ForeignKey("FollowingUserId")]
        public User FollowingUser { get; set; }
    }
}
