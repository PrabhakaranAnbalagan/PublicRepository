﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace TwitterClone.Domain
{
    public class User
    {
        [Required]
        [StringLength(24)]
        public string UserId { get; set; }

        [Required]
        [StringLength(40)]
        public string UserName { get; set; }

        [Required]
        [StringLength(80)]
        public string Email { get; set; }

        [Required]
        [StringLength(80)]
        public string Password { get; set; }

        [Required]
        public DateTime JoinedDate { get; set; }

        [Required]
        public bool IsActive { get; set; }
    }
}
